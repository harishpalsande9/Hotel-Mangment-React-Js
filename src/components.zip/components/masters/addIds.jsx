import React from "react";
import {
  Container,
  Row,
  ListGroup,
  Col,
  Tabs,
  Tab,
  Card,
  Form,
  Table,
  InputGroup,
  Button,
  FormControl,
} from "react-bootstrap";
import {
  FunnelFill,
  Plus,
  PlusCircle,
  PlusLg,
  Search,
} from "react-bootstrap-icons";
const AddIds = ({
  displayCompanyForm,
  companyFormStatus,
  displayReservationForm,
  handleChange,
  addReservation,
  formData,
  roomInfo,
  showRooms,
  showRoomStatus,
}) => {
  return (
    <>
      {roomInfo ? (
        <Form onSubmit={addReservation}>
          <Row className=" mb-2 pb-3">
            <Col>
              <Row>
                <Col>
                  <span className="bg-light">Add Room</span>
                </Col>
              </Row>
            </Col>

            <Col>
              <Row>
                <Col>
                  <Form.Control
                    className="form-control-sm"
                    placeholder="From Date"
                    value="19 Dec 21"
                    disabled
                  />
                </Col>
                <Col>
                  <Form.Control
                    className="form-control-sm"
                    value="20 Dec 21"
                    placeholder="To Date"
                  />
                </Col>
              </Row>
            </Col>
          </Row>

          <hr className="hr-1" />

          <Row className="mt-3 mb-3">
            <p>Guest Details</p>
            <Col className="col-2">
              <Form.Control className="form-control-sm" placeholder="Title" />
            </Col>
            <Col>
              <Form.Control
                className="form-control-sm"
                placeholder="First Name"
              />
            </Col>
            <Col>
              <Form.Control
                className="form-control-sm"
                placeholder="Last Name"
              />
            </Col>
            <Col>
              <Form.Control
                className="form-control-sm"
                placeholder="Room Number"
              />
            </Col>
          </Row>

          <Row className="mt-3 mb-3">
            <Col className="col-2 text-end">
              <FormControl
                type="text"
                className="form-control form-control-sm"
                placeholder="Found By"
              />
            </Col>
            <Col className="col-8 text-end">
              <FormControl
                type="text"
                className="form-control form-control-sm"
                placeholder="Remarks"
              />
            </Col>

            <Col className="text-end">
              <Button variant="light" size="sm">
                Upload Photo
              </Button>
            </Col>
          </Row>

          <div class="col-md-12 text-center">
            <Button variant="outline-dark" size="sm">
              Add Lost Items
            </Button>
          </div>
          <hr className="hr-1" />
        </Form>
      ) : (
        <Form onSubmit={addReservation}>
          <Row className="border-light  mb-2 pb-3">
            <Card body className="border-0">
              <span className="display-6 mb-2 bg-light">Setup ID's</span>
              <Row className="mt-3 mb-3 m-4">
                <Col className="text-center mx-2 p-2">
                  <Card body className="text-center border-0">
                    <h5>
                      <u>Reservation ID</u>
                    </h5>
                    <Form>
                      <Form.Group className="mb-3 mt-3">
                        <Form.Control
                          type="text"
                          placeholder="Length Of Reservation ID"
                        />
                        <Form.Text className="text-danger">
                          Length You Need For This Id. ex. 12
                        </Form.Text>
                      </Form.Group>

                      <Form.Group
                        className="mb-3 mt-3"
                        controlId="formBasicPassword"
                      >
                        <Form.Control
                          type="text"
                          placeholder="Starting String"
                        />
                        <Form.Text className="text-danger">
                          Starting String ex. ABCDE-
                        </Form.Text>
                      </Form.Group>
                      <div className="d-grid gap-2">
                        <Button variant="outline-dark" size="sm" type="submit">
                          Setup Reservation Id
                        </Button>
                      </div>
                    </Form>
                  </Card>
                </Col>
                <Col className="text-center mx-2 p-2">
                  <Card body className="text-center border-0">
                    <h5>
                      <u>Booking ID</u>
                    </h5>
                    <Form>
                      <Form.Group className="mb-3 mt-3">
                        <Form.Control
                          type="text"
                          placeholder="Length Of Booking ID"
                        />
                        <Form.Text className="text-danger">
                          Length You Need For This Id. ex. 10
                        </Form.Text>
                      </Form.Group>

                      <Form.Group
                        className="mb-3 mt-3"
                        controlId="formBasicPassword"
                      >
                        <Form.Control
                          type="text"
                          placeholder="Starting String"
                        />
                        <Form.Text className="text-danger">
                          Starting String ex. ABCDE-
                        </Form.Text>
                      </Form.Group>
                      <div className="d-grid gap-2">
                        <Button variant="outline-dark" size="sm" type="submit">
                          Setup Booking Id
                        </Button>
                      </div>
                    </Form>
                  </Card>
                </Col>
              </Row>
            </Card>
          </Row>
        </Form>
      )}
    </>
  );
};

export default AddIds;
